// Include node modules

const express = require('express');
const mysql = require('mysql');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const request = require('request');
const passport = require('passport');
const path = require('path');

const router = express.Router();

// Setting up credentials for the database
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});


///////////////////////////////////////////////////////////////////////////////////////////////////////////////

// GET Methods
// Get the / page. If user has a already existing session he is redirected to homepage, otherwise he is redirected to login page.
// The homeauthenticationMiddleware() checks for the same.
router.get('/',homeauthenticationMiddleware(), (req, res) => {
    res.redirect('/home')
});

// Get Login page
// The session of the user is forcefully destroyed if the user visits the login page.
router.get('/login', (req, res) => {
    const succmsg = req.flash('success')[0]
    const failmsg = req.flash('error')[0]
    
    req.logout();
    req.session.destroy();
    res.render('login', {
        success : succmsg,
        error : failmsg
    });

});

////// Remove /register in production environment  ///////

router.get('/register', (req, res) => {
    req.logout();
    req.session.destroy();
    res.render('register');
});


// GET the Home Page
// The authenticationMiddleware() checks if user is logged in or not. If not the user is redirected to login page with proper message.
// If the user is logged in then the functions in the get method are executed.
router.get('/home', authenticationMiddleware(), (req, res) => {
    res.render('home');
});


// GET the Purchase Orders Page
router.get('/purchase_orders', authenticationMiddleware(), (req, res) => {
   
    const vendorcode = req.session.passport.user
 
    db.query('SELECT PO_NUMBER,DATE_FORMAT(PO_DATE, "%d-%l-%Y") AS PO_DATE,PO_VALUE,PURCHASE_EXECUTIVE,CURRENCY FROM PO_TABLE WHERE VENDOR_CODE = ?', [vendorcode], async(error, results) => {
        
        res.render('purchase_orders', {
            msg: results
        });
    });
 
});

// GET the Bill Status Page
router.get('/bill_status', authenticationMiddleware(), (req, res) => {
 
    const vendorcode = req.session.passport.user
    console.log(vendorcode)
    db.query('SELECT BILL_REG , DATE_FORMAT(PO_DATE, "%d-%l-%Y") AS PO_DATE,DATE_FORMAT(VENDOR_INVOICE_DATE, "%d-%l-%Y") AS VENDOR_INVOICE_DATE, PO_NUMBER, VENDOR_INVOICE_NUMBER, STATUS,TAXABLE_VALUE,GST,INVOICE_VALUE,LD_INVOICE_NUMBER,LD_AMOUNT ,GST_LD,GST_TDS,INCOME_TAX,OTHER_HOLD,VOUCHER_PAYABLE_AMOUNT FROM BILL_STATUS WHERE VENDOR_CODE = ?', [vendorcode], async(error, results) => {
        //console.log(results);
        res.render('bill_status', {
            msg: results
        });
    });
 
});


// GET the TDS Page
router.get('/tds', authenticationMiddleware(), (req, res) => {
    const vendorcode = req.session.passport.user;
    db.query('SELECT * FROM TDS_TABLE WHERE VENDOR_CODE = ?', [vendorcode], async(error, results) => {
        //console.log(results)
        res.render('tds', {
            msg: results,
            type: "tds"
        })
    });
    
});


// GET the TCS Page
router.get('/tcs', authenticationMiddleware(), (req, res) => {
    const vendorcode = req.session.passport.user;
    db.query('SELECT * FROM TCS_TABLE WHERE VENDOR_CODE = ?', [vendorcode], async(error, results) => {
        //console.log(results)
        res.render('tcs', {
            msg: results,
            type: "tcs"
        })
    });
});


// GET the GST TDS Page
router.get('/gst_tds', authenticationMiddleware(), (req, res) => {
    const vendorcode = req.session.passport.user;
    db.query('SELECT * FROM GSTTDS_TABLE WHERE VENDOR_CODE = ?', [vendorcode], async(error, results) => {
        //console.log(results)
        res.render('gst_tds', {
            msg: results,
            type: "gsttds"
        })
    });
});

// GET the LD Invoice Page
router.get('/ld_invoice', authenticationMiddleware(), (req, res) => {
    const vendorcode = req.session.passport.user;
    db.query('SELECT *, LD_INVOICE_NUMBER,DATE_FORMAT(LD_INVOICE_DATE, "%d-%l-%Y") AS LD_INVOICE_DATE, DATE_FORMAT(PO_DATE, "%d-%l-%Y") AS PO_DATE, VENDOR_INVOICE_NUMBER, DATE_FORMAT(VENDOR_INVOICE_DATE, "%d-%l-%Y") AS VENDOR_INVOICE_DATE FROM LDINV_TABLE WHERE VENDOR_CODE = ?', [vendorcode], async(error, results) => {
        //console.log(results);
        res.render('ld_invoice', {
            msg: results
        });
    });
    
});

// Action to be done on Logout
router.get('/logout', (req, res) => {
    req.flash('success', 'You have successfully logged out!')
    res.redirect('/login')
});


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// POST Methods

// POST /register is for dummy registration.
////// Remove /register in production environment  ///////
router.post('/register', (req, res) => {
    //console.log(req.body);

    const vendorcode = req.body.vendorcode;
    const password = req.body.password;


    db.query('SELECT VENDOR_CODE FROM users WHERE VENDOR_CODE = ?', [vendorcode], async(error, results) => {
        if(error){
            console.log(error);
        }


        if(results.length >0 ){
            return res.render('register', {
                message: "This vendor is already registered."
            })
        }

        let hashedPassword = await bcrypt.hash(password, 8);
        //console.log(hashedPassword);

        db.query('INSERT INTO users SET ?', {VENDOR_CODE: vendorcode, PASSWORD: hashedPassword}, (error, results) => {
            if(error){
                console.log(error);
            }
            else{
                return res.render('register', {
                    message: "Vendor successfully registered."
                });
            }
        });


    });

} )

// POST Login to authenticate a User after checking the credentials and captcha.
router.post('/login', (req, res) => {
    try{
        
        //console.log(req.body);
        const vendorcode = req.body.vendorcode;
        const password = req.body.password;
        const captcha = req.body['g-recaptcha-response']
        
        if( !vendorcode || !password ){
            return res.status(400).render('login', {
                error: "Please provide Username and Password"
            });
        }

        if(
            captcha === undefined ||
            captcha === '' ||
            captcha === null
         ){
            return res.render('login', {
               
                error: "Please select captcha!"
            });
            }

        // If all fields have been entered then check for captcha.    
        
        // Google reCAPTCHA Verification
        
        // Secret Key  // You have to replace this with your secret key that you get from google reCAPTCHA after logging in there with your Google Account
        const secretKey = '6Len5PoUAAAAAEQwZInoO6uIFfp2gC8i-eLIkFuR';

        // Captcha Verification URL
        const verifyUrl = `https://google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${captcha}&remoteip=${req.connection.remoteAddress}`;

        // Make Request to verify URL
        request(verifyUrl, (err, response, body) => {
            body = JSON.parse(body);
           // console.log(body)

            // If not successful
            if(body.success !== undefined && !body.success){
                return res.render('login', {
                    error: "Failed captcha verification!"
                });
            }

            // Captcha verification completed

            // This part is executed if the captcha verification was successful

         
            // This part checks whether the (Vendor Code, Password) is in our database or not.
            db.query('SELECT * FROM users WHERE VENDOR_CODE = ?', [vendorcode], async(error, results) => {
                //console.log(results);
                if(results.length === 0){
                    return res.status(401).render('login', {
                        error: "Incorrect Vendor Code or Password!"
                    })
                }
                if(!results || !(await bcrypt.compare(password, results[0].PASSWORD))){  // Change the password hash function here 
                    res.status(401).render('login', {
                        error: "Incorrect Vendor Code or Password!"
                    })
                }else{
                    // If password matches login the vendor and redirect to home page
                    
                    req.login(vendorcode, () =>{
                        res.redirect('/home')
                    });
                }
            });


        });


    }catch(error){
        console.log(error);
    }
})


// POST for certificate downloads

router.post('/download', authenticationMiddleware(), (req, res) =>{
    // console.log(req.user);
    // console.log(req.isAuthenticated());
    // console.log(req.body);
    const vendorcode = req.session.passport.user;
    const number = req.body.number;
    const type = req.body.type;

    // Download TDS Certificates
    if(type === "tds"){
        console.log("TDS")
        db.query('SELECT * FROM TDS_TABLE WHERE VENDOR_CODE = ? AND TDS_CERTIFICATE_NUMBER= ?', [vendorcode, number], async(error, results) => {
            if(results.length === 1){
                //console.log("OK till now.....lets download the file");
                var file = number+'.pdf'                                    // Filename + extension of the PDF
                var fileLocation = path.join('./certificates/tds',file);    // Get final file location
                console.log(fileLocation);
                res.download(fileLocation, file, (err) => {                 // Download the file
                    if(err){
                        res.send("Status: "+err.status + "<h1>File not found<h1>")
                    }
                });
            }

        });

    }

    // Download TCS Certificates
    if(type === "tcs"){
        console.log("TCS")
        db.query('SELECT * FROM TCS_TABLE WHERE VENDOR_CODE = ? AND TCS_CERTIFICATE_NUMBER= ?', [vendorcode, number], async(error, results) => {
            if(results.length === 1){
                //console.log("OK till now.....lets download the file");
                var file = number+'.pdf'
                var fileLocation = path.join('./certificates/tcs',file);
                console.log(fileLocation);
                res.download(fileLocation, file, (err) => {
                    if(err){
                        res.send("Status: "+err.status + "<h1>File not found<h1>")
                    }
                });
            }

        });

    }


    // Download GST TDS Certificates
    if(type === "gsttds"){
        console.log("GST TDS")
        db.query('SELECT * FROM GSTTDS_TABLE WHERE VENDOR_CODE = ? AND GSTTDS_CERTIFICATE_NUMBER= ?', [vendorcode, number], async(error, results) => {
            if(results.length === 1){
                //console.log("OK till now.....lets download the file");
                var file = number+'.pdf'
                var fileLocation = path.join('./certificates/gsttds',file);
                console.log(fileLocation);
                res.download(fileLocation, file, (err) => {
                    if(err){
                        res.send("Status: "+err.status + "<h1>File not found<h1>")
                    }
                });
            }

        });

    }



});


// Middleware to check if the user is authenticated
function authenticationMiddleware () {  
	return (req, res, next) => {
		//console.log(`req.session.passport.vendorcode: ${JSON.stringify(req.session.passport)}`);

        if (req.isAuthenticated()) return next();
        req.flash('error', 'Not logged in, please login to continue!')
	    res.redirect('/login')
	}
}


function homeauthenticationMiddleware () {  
	return (req, res, next) => {
		//console.log(`req.session.passport.vendorcode: ${JSON.stringify(req.session.passport)}`);

        if (req.isAuthenticated()) return next();
	    res.redirect('/login')
	}
}

// Passport Serialize and Deserialize
passport.serializeUser(function(vendorcode, done) {
    done(null, vendorcode);
  });
  
passport.deserializeUser(function(vendorcode, done) {
    done(null, vendorcode);
  });

module.exports = router;
