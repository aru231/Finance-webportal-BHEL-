// Include node modules

const express = require('express');
const bodyParser = require('body-parser');
const request = require('request');
const path = require('path');
const mysql = require('mysql');
const dotenv = require('dotenv');
const session = require('express-session');
const passport = require('passport');
const MySQLStore = require('express-mysql-session')(session);
const flash = require('connect-flash')


// Configure path to .env file which contains the environment variables
dotenv.config({ path: './.env'});

const app = express();

const publicDirectory = path.join(__dirname, './public');         // Join path to public folder   
app.use(express.static(publicDirectory));                         // Serve public files like CSS,Favicon
app.use(express.urlencoded({extended: false}));                   // For parsing URL encoded bodies
app.use(express.json());


//////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Setting up credentials for the database that contains all the tables + table that contains (Vendor Code, Password)
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

// Connecting to the database
db.connect( (error) => {
    if(error){
        console.log(error)
    }
    else{
        console.log('Connected with database...')
    }
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Setting up the Session Store (The database that will store sessions for the logged in user.)
// More details can be found at https://www.npmjs.com/package/express-session
const options = {
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
};

var sessionStore = new MySQLStore(options);

// Defining the maximum time for which an inactive session should last (The time should be in milliseconds)
const age = 1000*60*30;                 // 18 lac ms or 30 mins

// All parameters given below can be found in the npm documentation - https://www.npmjs.com/package/express-session
// Refer to cookie.secure option to set up secure cookies via HTTPS in production environment and do changes accordingly.
app.use(session({
    secret: 'randomstringhere',             // Put a random string here using some random string generator
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: { maxAge: age  }
  }))
  
app.use(passport.initialize());             // Initialize Passport 
app.use(passport.session());
app.use(flash());                           // Connect flash for flash messages

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

app.set('view engine', 'ejs');          // Setting up view engine - EJS



// Include routes/auth which contains all GET POST actions 
app.use('/', require('./routes/auth'))



// Starting the server
const PORT = 3000 || process.env.PORT
app.listen(PORT, () => {
    console.log(`Server started on http://localhost:${PORT}`);
});